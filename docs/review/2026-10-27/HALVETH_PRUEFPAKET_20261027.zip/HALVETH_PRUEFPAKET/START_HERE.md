# HALVETH · Prüfpaket für eine zweite Person

Die öffentlichen Änderungen lassen sich jetzt ohne Zugriff auf lokale Originalakten nachprüfen. Einstieg: **PROJEKTKARTE.html** oder **PROJEKTKARTE.md**.

Dieses Paket enthält die 69er-Projektzuordnung, öffentliche Commit-/Pfadverweise, 48 genau benannte Webressourcen und ein lesbares Python-Prüfskript. Die Zuordnung behält ihren eigenen datierten Stand. Die aktuelle Webprüfung bindet Portfolio-Commit `a0dd6c81f54a025c01c54b0408066c5f6daa3e01`.

## 1. Paket unverändert angekommen?

Nach dem Entpacken im Paketordner (Python 3.11+):

```sh
python verify.py
```

Erwartung: `PACKAGE_INTEGRITY: .../...`. Das prüft Bytegleichheit mit dem beiliegenden Manifest.

## 2. Stimmen die 48 öffentlichen Quell- und Website-Dateien?

```sh
python verify.py --source --live
```

Das Skript liest die Dateien am unveränderlichen GitHub-Commit und von der öffentlichen Website. Erwartung beim gebundenen veröffentlichten Stand: `SOURCE_BYTES: 48/48` und `LIVE_BYTES: 48/48`. Nach einer weiteren Veröffentlichung darf der Live-Vergleich abweichen; die Commitprüfung bleibt auf dieser Fassung.

## 3. Sind die 69 erhaltenen Branches noch an derselben Stelle?

Zusätzlich Git installiert:

```sh
python verify.py --branches
```

Vier öffentliche Referenzlisten werden gelesen. Erwartung im erhaltenen Stand: `BRANCH_REFS: {"SAME": 69}`. Ein weiterentwickelter Kopf wird als `CHANGED` sichtbar; ein fehlender als `MISSING`.

## 4. Was kann ein Mensch tatsächlich ausprobieren?

**NOVA:** [gebundene Startanleitung](https://github.com/Juri-Halveth/lucinet-seedspace/tree/226609eeb31be20db71ecf42af5df73c3a86adf2). Eine frische Demo anlegen und anschließend `verify` ausführen. Notieren: Welche Quelle wurde gefunden, welche Korrektur erhalten, welcher nächste Schritt angezeigt?

**Tresor:** [gebundene Anleitung](https://github.com/Juri-Halveth/halveth-tresor/tree/e1ca9830e84099f0e4a9a4bfdede919a5ab0eee6). Für einen ersten Funktionstest ausschließlich erfundene Zugangsdaten in einem neuen Testtresor verwenden. Speichern, schließen, wieder öffnen und den eigenen Prüfweg notieren. Der lokal geprüfte Windows-Build ist bislang unsigniert; ein unabhängiger Security Review bleibt eine eigene Aufgabe.

**Mein Lernportal:** [öffentliche Anwendung](https://juri-halveth.github.io/mein-lernportal/) und [gebundener Quellstand](https://github.com/Juri-Halveth/mein-lernportal/tree/dbf2c9588b0bf0ef8ddeacd5fad9452e216b6c1b). Eine Lektion öffnen, eine Aufgabe bearbeiten, die Seite neu laden und den lokalen Fortschritt prüfen.

**Field Difference Lab:** [öffentliche Anwendung](https://juri-halveth.github.io/halveth-field-difference-lab/) und [gebundener Quellstand](https://github.com/Juri-Halveth/halveth-field-difference-lab/tree/4c1b8ea108d136450be7a1b80d006654181d67e1). Gleiche Ausgangslage und eine veränderte Modellregel vergleichen; die beobachtete Änderung mit der Erklärung abgleichen.

Die Browserlinks zeigen den jeweiligen aktuellen veröffentlichten Stand. Die danebenstehenden Quelllinks binden die genannte historische Revision.

## Rückmeldung, die uns tatsächlich weiterhilft

1. Datum, Betriebssystem und Programm-/Browserversion.
2. Benutzter Link oder Commit und genaue Schritte.
3. Erwartetes Ergebnis und tatsächlich gesehenes Ergebnis.
4. Eine konkrete Unklarheit oder reproduzierbare Abweichung.

Die Tests und dieses Paket stammen aus derselben Arbeitsumgebung. Eine neue externe Bestätigung entsteht erst durch die eigene Prüfung einer anderen Person. Rückmeldungen bleiben zunächst bei der prüfenden Person; das Skript lädt keine Berichte hoch.

## Quellen und Änderungen

Reparatur-PRs: [Portfolio #41](https://github.com/Juri-Halveth/Juri-Halveth.github.io/pull/41), [Profil #19](https://github.com/Juri-Halveth/Juri-Halveth/pull/19), [NOVA #13](https://github.com/Juri-Halveth/lucinet-seedspace/pull/13), [NOVA #14](https://github.com/Juri-Halveth/lucinet-seedspace/pull/14), [Tresor #21](https://github.com/Juri-Halveth/halveth-tresor/pull/21), [Lernportal #8](https://github.com/Juri-Halveth/mein-lernportal/pull/8), [Field Lab #3](https://github.com/Juri-Halveth/halveth-field-difference-lab/pull/3). Nachbesserung: [Portfolio #42](https://github.com/Juri-Halveth/Juri-Halveth.github.io/pull/42).

Die gezeigten Werke behalten ihre jeweiligen [Lizenzzuordnungen](https://github.com/Juri-Halveth/Juri-Halveth.github.io/blob/a0dd6c81f54a025c01c54b0408066c5f6daa3e01/LICENSES.md). Dieses Prüfverzeichnis erweitert weder Lizenzgrants noch Eigentums- oder Wirkungsbehauptungen.
