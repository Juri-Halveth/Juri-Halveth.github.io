"""Read-only verifier for the minimized public review package (Python 3.11+).

No account, token, upload, installation or remote mutation is used.
Default: local package integrity. --source / --live: public HTTP reads.
--branches: four git ls-remote reads of the named public repositories.
"""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import urllib.request
from urllib.parse import quote


ROOT = Path(__file__).resolve().parent
OWNER = "Juri-Halveth"
REPO = "Juri-Halveth.github.io"


def load(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def source_path(value):
    if not isinstance(value, str) or "\\" in value or ":" in value or "\x00" in value:
        raise ValueError("Explicit relative source path required")
    parsed = PurePosixPath(value)
    if parsed.is_absolute() or any(part in ("", ".", "..") for part in value.split("/")):
        raise ValueError("Invalid source path")
    return value


def local_integrity():
    manifest = load("MANIFEST.json")
    for entry in manifest["files"]:
        path = source_path(entry["path"])
        data = (ROOT / path).read_bytes()
        if len(data) != entry["bytes"] or sha(data) != entry["sha256"]:
            raise ValueError("Package integrity mismatch: " + path)
    print(f"PACKAGE_INTEGRITY: {len(manifest['files'])}/{len(manifest['files'])}")


def http_check(mode):
    manifest = load("PUBLIC_RESOURCES.json")
    commit = manifest["commit"]
    if not re.fullmatch(r"[a-f0-9]{40}", commit):
        raise ValueError("Immutable commit required")

    def check(entry):
        path = source_path(entry["path"])
        encoded = quote(path, safe="/")
        url = (f"https://raw.githubusercontent.com/{OWNER}/{REPO}/{commit}/{encoded}" if mode == "source"
               else f"https://juri-halveth.github.io/{encoded}?verify={commit}")
        request = urllib.request.Request(url, headers={"User-Agent": "HALVETH-public-review/1", "Cache-Control": "no-cache"})
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                body = response.read(16_000_001)
                if len(body) > 16_000_000:
                    raise ValueError("Public resource size limit")
            actual = sha(body)
            return {"path": path, "matches": actual == entry["sha256"], "actualSha256": actual}
        except Exception as error:
            return {"path": path, "matches": False, "error": str(error)}

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(check, manifest["files"]))
    count = sum(row["matches"] for row in rows)
    print(f"{mode.upper()}_BYTES: {count}/{len(rows)} at {commit}")
    for row in rows:
        if not row["matches"]:
            print(json.dumps(row, ensure_ascii=False))
    if count != len(rows):
        raise SystemExit(1)


def branch_check():
    rows = load("PROJECT_ASSIGNMENT.json")["rows"]
    repositories = {"halveth-scarlet", "Juri-Halveth.github.io", "Juri-Halveth", "halveth-tresor"}
    if {row["repository"] for row in rows} != repositories or len(rows) != 69:
        raise ValueError("Expected the 69-branch, four-repository snapshot")
    refs = {}
    for repo in sorted(repositories):
        output = subprocess.run(["git", "ls-remote", "--heads", f"https://github.com/{OWNER}/{repo}.git"], capture_output=True, text=True, check=True, timeout=60).stdout
        refs[repo] = {}
        for line in output.splitlines():
            if not line:
                continue
            digest, name = line.split("\t", 1)
            refs[repo][name.removeprefix("refs/heads/")] = digest
    counts = Counter()
    for row in rows:
        current = refs[row["repository"]].get(row["branch"])
        state = "SAME" if current == row["sha"] else "MISSING" if current is None else "CHANGED"
        counts[state] += 1
        if state != "SAME":
            print(json.dumps({"repository": row["repository"], "branch": row["branch"], "state": state}))
    print("BRANCH_REFS:", json.dumps(dict(counts)))
    if counts["SAME"] != 69:
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", action="store_true", help="Compare 48 public source files at the immutable commit")
    parser.add_argument("--live", action="store_true", help="Compare the current public website with the bound commit")
    parser.add_argument("--branches", action="store_true", help="Read the four public Git reference lists")
    args = parser.parse_args()
    local_integrity()
    if args.source:
        http_check("source")
    if args.live:
        http_check("live")
    if args.branches:
        branch_check()
