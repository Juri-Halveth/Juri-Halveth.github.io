# Die 69 Branches haben jetzt eine Projektkarte

Alle 69 ausgewählten Remote-Branches bleiben erhalten. Die Zuordnung wurde aus Dateien, Commit-Verlauf und begrenzten Texteinstiegen abgeleitet.

Prüfstand (UTC): 2026-10-27T20:41:19.743300Z. Umfang: vier öffentliche Repositories; 129 gebundene Remote-Köpfe in der Graphprüfung.

[Durchsuchbare Karte](PROJEKTKARTE.html) · [Vollständiges JSON](PROJECT_ASSIGNMENT.json) · [CSV](PROJECT_ASSIGNMENT.csv)

## Übersicht

| Projektbereich | Branches | Weitere Einzelprüfung |
| --- | ---: | ---: |
| [Kommunaler Pilot · JURI-THESIS](#juri_thesis) | 33 | 0 |
| [ASHBOUND · Browser und Unreal](#ashbound) | 6 | 1 |
| [Weltkeimwerk · G-Star](#gstar) | 4 | 0 |
| [Grenzbeobachter und Übergangswerkstatt](#grenzbeobachter) | 2 | 0 |
| [SCARLET · Oberfläche und Betrieb](#scarlet_platform) | 5 | 1 |
| [Portfolio und Quellenhandbuch](#portfolio) | 7 | 2 |
| [GitHub-Profil](#github_profile) | 5 | 0 |
| [Tresor · Projektanleitung](#tresor) | 2 | 0 |
| [Eigenständige Methodenbeispiele](#methods) | 2 | 1 |
| [schülerVZ · Archivbetrieb](#schuelervz) | 1 | 1 |
| [Handschriftliche Konvergenzen](#handschrift) | 1 | 0 |
| [VOID25 · Rechte und Snapshot](#rights) | 1 | 1 |

## Was die Integrationsprüfung ergeben hat

- **55 Branches:** Zu ihren einzelnen Nicht-Merge-Commits gibt es entsprechende stabile Git-Patch-IDs in der main-Historie.
- **7 weitere Branches:** Ihr Gesamtpatch stimmt mit dem Delta eines passenden gemergten PRs überein; dessen Merge-Commit ist Vorfahr des gebundenen main.
- **3 Branches:** Sämtliche geänderten Pfade sind in main noch am gemeinsamen Ausgangsstand: native ASHBOUND-Fortsetzung, Hypothesen-Revision und VOID25-Metadaten.
- **4 Branches:** Gemischte Abweichungen bleiben zur Einzelprüfung erhalten: News-Konfiguration, schülerVZ-Refresh, frühere ASHBOUND-Portfolioseite und Quellenuniversum.

Die Übernahmespur betrifft Git-Änderungspatches. Spätere Bearbeitung oder Entfernung bleibt in der heutigen Dateiansicht sichtbar. Whitespace-unempfindliche Patch-ID-Gleichheit ist enger als eine Laufzeit- oder Bedeutungsprüfung.

## Besonders wichtig

**ASHBOUND visual-balance ist gemeinsame Vorgeschichte aktiver Arbeit.** Der erhaltene Stand enthält 17 branchseitige Commits und 36 geänderte Pfade. Sein Commit ist Vorfahr der Köpfe von vier offenen PRs: [#67](https://github.com/Juri-Halveth/halveth-scarlet/pull/67), [#68](https://github.com/Juri-Halveth/halveth-scarlet/pull/68), [#73](https://github.com/Juri-Halveth/halveth-scarlet/pull/73) und [#76](https://github.com/Juri-Halveth/halveth-scarlet/pull/76). Der Stand bleibt im Entwicklungsbereich; die aktuelle öffentliche Projektauswahl bleibt erhalten.

**Zwei unscheinbare Branch-Namen enthalten Methoden-Code.** `claimed-zda-correction` enthält einen eigenen Hypothesen-Revision-Zyklus mit CLI und Adapter. `ordinary-grip` enthält ein Greif-/Weltkontext-Zustandsmodell. Beide sind jetzt als separate Beispiele auffindbar; ihre Themen werden durch die gemeinsame Rubrik nicht gleichgesetzt.

**Ein historischer Entwurf erhält durch diese Karte keinen aktuellen Produktstatus.** Frühere Spielewerbung, Kompetenzdarstellungen und Studien bleiben als historische Quellen zugeordnet. Rechte- und Lizenzdateien werden separat geführt.

## Alle Branches nach Projekt

<a id="juri_thesis"></a>
### Kommunaler Pilot · JURI-THESIS

Konzept, Auswahl, Chancenreise, Wirtschaftsmodell und Brühler Wirkungsatlas.

| ID / Branch | Inhalt | Übernahmespur / Prüfstand |
| --- | --- | --- |
| B014 · [codex/juri-thesis-asset-cache-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/4076ff08497cb25f3229c11ef3fd075c663d9583)<br>`halveth-scarlet` · `4076ff08497c` | Inhaltsgebundene Asset-Versionen und Quellenlinks | Einzelpatch in main-Historie |
| B015 · [codex/juri-thesis-bruehl-baseline-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/bb0822d75f09071089f60bb06585bfd6424a554c)<br>`halveth-scarlet` · `bb0822d75f09` | Datierte kommunale Ausgangsdaten | Einzelpatch in main-Historie |
| B016 · [codex/juri-thesis-bruehl-deeproutes-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/ff46ea9003d7b503325200875fc46252c26c4286)<br>`halveth-scarlet` · `ff46ea9003d7` | Lokale Wirkungswege und Arbeitgeberrechnung | Einzelpatch in main-Historie |
| B017 · [codex/juri-thesis-bruehl-realitaetsanker-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/a0b7de65be8caa1772e8d310d797b960b8fd90f5)<br>`halveth-scarlet` · `a0b7de65be8c` | Drei dokumentierte lokale Beispiele | Einzelpatch in main-Historie |
| B018 · [codex/juri-thesis-bruehl-taxroutes-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/18e507adeedd9310ba249e4af2e6d215f72ba68d)<br>`halveth-scarlet` · `18e507adeedd` | Kommunale Steuerzuordnung im Wirkungsatlas | Einzelpatch in main-Historie |
| B019 · [codex/juri-thesis-bruehl-wirkungsatlas-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/56e9e344ae45df2d0495aaadeee0077fcf149232)<br>`halveth-scarlet` · `56e9e344ae45` | Quellenbasierter Brühler Wirkungsatlas | Einzelpatch in main-Historie |
| B020 · [codex/juri-thesis-budget-status-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/7ed192cf24db6a18930d57db81fcd2efaee8c3ca)<br>`halveth-scarlet` · `7ed192cf24db` | Stand der Brühler Haushaltsberatung im Finanzierungsmodell | Einzelpatch in main-Historie |
| B021 · [codex/juri-thesis-city-employer-paths-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/a9bbd9bd78381538e4450542c9184dba3218a260)<br>`halveth-scarlet` · `a9bbd9bd7838` | Kommunale Beschäftigungswege | Einzelpatch in main-Historie |
| B022 · [codex/juri-thesis-clear-pilot-20261013](https://github.com/Juri-Halveth/halveth-scarlet/tree/e6869b84dcb7805d6b8427c325dfc5d22a9cfc25)<br>`halveth-scarlet` · `e6869b84dcb7` | Pilotkonzept, Auswahl und Pilotbrief | Gesamtpatch in main-Historie |
| B023 · [codex/juri-thesis-cohesion-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/0224d7e5c90b6e91a3c85309e7a600207e1b801a)<br>`halveth-scarlet` · `0224d7e5c90b` | Abgleich der Unterseiten und Reparatur des Modells | Einzelpatch in main-Historie |
| B024 · [codex/juri-thesis-compact-paths-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/76ab1e76b9a5141b7ba4650fbb50e77f9dbc4e6b)<br>`halveth-scarlet` · `76ab1e76b9a5` | Kompakte, aufklappbare Wirkungskarten | Einzelpatch in main-Historie |
| B025 · [codex/juri-thesis-count-reconcile-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/d9fb7ce968b6d7e8d485196a61d676abcbf2ae89)<br>`halveth-scarlet` · `d9fb7ce968b6` | Abgleich der Zahl beschriebener Wirkungswege | Einzelpatch in main-Historie |
| B026 · [codex/juri-thesis-direct-story-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/4e52977c3a5681104a546516253b75ed12249767)<br>`halveth-scarlet` · `4e52977c3a56` | Direkte Teilnehmergeschichte in Konzept und Pilotbrief | Einzelpatch in main-Historie |
| B027 · [codex/juri-thesis-economic-brief-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/2ab8ebd575a1a2211b65320005c3cc7461d82f62)<br>`halveth-scarlet` · `2ab8ebd575a1` | T+6-/T+12-Wirtschaftsmodell und Modelltests | Einzelpatch in main-Historie |
| B028 · [codex/juri-thesis-fiscal-net-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/70cae583e898972bf61db33a7694286efaabfd2b)<br>`halveth-scarlet` · `70cae583e898` | Finanzausgleich im Wirkungsmodell | Einzelpatch in main-Historie |
| B029 · [codex/juri-thesis-focused-story-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/067a04897199f0f769632b701a56475ab94ebbef)<br>`halveth-scarlet` · `067a04897199` | Erzählfokus, Alterskurve und Zitatkorrektur | Einzelpatch in main-Historie |
| B030 · [codex/juri-thesis-four-impact-paths-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/ad55c5cbba714f599989623b3ecc851eca094d59)<br>`halveth-scarlet` · `ad55c5cbba71` | Vier Lebenswege und lokales Ausgabenmodell | Einzelpatch in main-Historie |
| B031 · [codex/juri-thesis-future-challenge-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/c7f38bc3d7bed6c244e9eaff4d472de6409990c5)<br>`halveth-scarlet` · `c7f38bc3d7be` | Drei Zukunftswege und Pilotbrief-Erstellung | Einzelpatch in main-Historie |
| B032 · [codex/juri-thesis-ich-versand-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/51225f54b8c8178a68725601b132af4aab169be9)<br>`halveth-scarlet` · `51225f54b8c8` | Ich-Perspektive des persönlichen Vorschlags | Einzelpatch in main-Historie |
| B033 · [codex/juri-thesis-image-language-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/777baff42fd50680430055912373e21587c2f5b5)<br>`halveth-scarlet` · `777baff42fd5` | Bildsprache der Konzepterklärung | Einzelpatch in main-Historie |
| B034 · [codex/juri-thesis-kita-paths-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/65320db868b3419353f43035545696fb8c3b0195)<br>`halveth-scarlet` · `65320db868b3` | Kinderbetreuung, Jugendrolle und Ausbildungsbeispiel | Gesamtpatch in main-Historie |
| B035 · [codex/juri-thesis-local-youth-routes-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/5eee16fce7d199576a0b865d2f11d5bc69c6ac04)<br>`halveth-scarlet` · `5eee16fce7d1` | Weitere örtliche Jugendangebote | Einzelpatch in main-Historie |
| B036 · [codex/juri-thesis-man-voice-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/7b2ca946275f79198a84d550d74afe762d2357b2)<br>`halveth-scarlet` · `7b2ca946275f` | Unpersönliche Erzählperspektive in Web und PDF | Einzelpatch in main-Historie |
| B037 · [codex/juri-thesis-more-young-paths-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/427bac3f8d125a44dbaca9d72c484fa50e2c78d7)<br>`halveth-scarlet` · `427bac3f8d12` | Praxis-, Pflege- und Kulturwege | Einzelpatch in main-Historie |
| B038 · [codex/juri-thesis-open-seats-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/57e5010f2dae4a5292ca6e2cbcadd18272f3175e)<br>`halveth-scarlet` · `57e5010f2dae` | Offene Nominierungsplätze im 1+3-Vorschlag | Einzelpatch in main-Historie |
| B039 · [codex/juri-thesis-partner-map-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/450e6f5d233380f1782a25ddf11e10301b16def4)<br>`halveth-scarlet` · `450e6f5d2333` | Partnerrollen und bestehende Förderregeln | Einzelpatch in main-Historie |
| B040 · [codex/juri-thesis-plain-counterarguments-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/afba08472e94343666ab7c6108fbda107f69a243)<br>`halveth-scarlet` · `afba08472e94` | Verständlichere, quellengebundene Gegenargumente | Einzelpatch in main-Historie |
| B041 · [codex/juri-thesis-public-dispatch-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/7e564250fa0fd0149578efdb55fca9007d101820)<br>`halveth-scarlet` · `7e564250fa0f` | Öffentlicher Versandstand und gemeldeter Versandzeitpunkt | Gesamtpatch in main-Historie |
| B042 · [codex/juri-thesis-public-value-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/ebb6a3dcdc1bebb410437957909385a9844e5d2f)<br>`halveth-scarlet` · `ebb6a3dcdc1b` | Kommunaler Leistungswert und privater Arbeitgeberertrag | Einzelpatch in main-Historie |
| B043 · [codex/juri-thesis-stadtwerke-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/9cfaae20c95ab292c5a0f686b40c3f1e19506c63)<br>`halveth-scarlet` · `9cfaae20c95a` | Versorger-, Wasser- und Ausbildungswege mit Quellenbezug | Gesamtpatch in main-Historie |
| B044 · [codex/juri-thesis-storybook-support-20261013](https://github.com/Juri-Halveth/halveth-scarlet/tree/04b588a685ac04cdfe7d7afc5fd1d080f9e875da)<br>`halveth-scarlet` · `04b588a685ac` | 30-Personen-Geschichte mit Unterstützungswegen | Einzelpatch in main-Historie |
| B045 · [codex/juri-thesis-water-location-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/a02f807b2624af7bf24b4e023d8c74a197a09a7d)<br>`halveth-scarlet` · `a02f807b2624` | Wasser-/Abwasserweg am tatsächlichen Arbeitsort | Einzelpatch in main-Historie |
| B046 · [codex/juri-thesis-young-residence-20261014](https://github.com/Juri-Halveth/halveth-scarlet/tree/572da5ccafa710c271dfcb731c35f7fbe86c9f47)<br>`halveth-scarlet` · `572da5ccafa7` | Wohnen junger Erwachsener und lokale Ausgangsdaten | Einzelpatch in main-Historie |

<a id="ashbound"></a>
### ASHBOUND · Browser und Unreal

Spielprolog, Desktop-Einstieg, native Welt und weitere experimentelle Weltentwicklung.

| ID / Branch | Inhalt | Übernahmespur / Prüfstand |
| --- | --- | --- |
| B001 · [codex/ashbound-first-person](https://github.com/Juri-Halveth/halveth-scarlet/tree/2cdbe2430afa0b1eac60db0b64241a48443dccc2)<br>`halveth-scarlet` · `2cdbe2430afa` | Browser-Prolog, Lore-Bücher und Desktop-Einstieg | Einzelpatch in main-Historie |
| B002 · [codex/ashbound-grove-material](https://github.com/Juri-Halveth/halveth-scarlet/tree/3e9a16279b433e78054cdf61e6075a919080a07b)<br>`halveth-scarlet` · `3e9a16279b43` | Native Blattmaterialien und Paketprüfung | Einzelpatch in main-Historie |
| B003 · [codex/ashbound-living-world](https://github.com/Juri-Halveth/halveth-scarlet/tree/2dfeda77381aa83d2d91bd342568018e51ba8de7)<br>`halveth-scarlet` · `2dfeda77381a` | Instanzierte Haine und nativer Template-Import | Einzelpatch in main-Historie |
| B004 · [codex/ashbound-native-entry](https://github.com/Juri-Halveth/halveth-scarlet/tree/59338d449541702052255d50efd8ca6318bc5852)<br>`halveth-scarlet` · `59338d449541` | Browser-Einstieg zur nativen Vorschau | Einzelpatch in main-Historie |
| B005 · [codex/ashbound-native-unreal](https://github.com/Juri-Halveth/halveth-scarlet/tree/00205beed2f57c3c38506eb02d73ce6219bbc129)<br>`halveth-scarlet` · `00205beed2f5` | Native Unreal-Vorschau und reaktive Zauber | Gesamtpatch in main-Historie |
| B006 · [codex/ashbound-visual-balance](https://github.com/Juri-Halveth/halveth-scarlet/tree/e0395b2cc6dec1ed4f3f61effd4f5ab7ec6dd77b)<br>`halveth-scarlet` · `e0395b2cc6de` | 17 Commits zu nativer Welt, Terrain, Büchern, Behausung und optionalem lokalem Dialog | Eigenständiger Quellstand |

<a id="gstar"></a>
### Weltkeimwerk · G-Star

Lokale Zustände, Genesis-Ledger, bewegte Profile und Membrankontakte.

| ID / Branch | Inhalt | Übernahmespur / Prüfstand |
| --- | --- | --- |
| B008 · [codex/gstar-live-20261006](https://github.com/Juri-Halveth/halveth-scarlet/tree/2c87d9067a8a9e2482971374b959f9f6059dc8a0)<br>`halveth-scarlet` · `2c87d9067a8a` | Bewegter lokaler Zellraum und Live-Oberfläche | Einzelpatch in main-Historie |
| B009 · [codex/gstar-live-cache-20261006](https://github.com/Juri-Halveth/halveth-scarlet/tree/328efaafbae8f3bcb9a50e527f81df70b9a518f4)<br>`halveth-scarlet` · `328efaafbae8` | Cachebindung des Weltkeimwerk-Einstiegs | Einzelpatch in main-Historie |
| B010 · [codex/gstar-membrane-20261006](https://github.com/Juri-Halveth/halveth-scarlet/tree/5b570d8573817e6b1a7fadc6d6c49453ee1c14f8)<br>`halveth-scarlet` · `5b570d857381` | Bewegte Profile und Membrankontakt | Einzelpatch in main-Historie |
| B011 · [codex/gstar-weltkeimwerk-20261006](https://github.com/Juri-Halveth/halveth-scarlet/tree/5c78afc2d811224df83386961e7f6690f799755f)<br>`halveth-scarlet` · `5c78afc2d811` | Weltkeimwerk-Kern und lokales Genesis-Ledger | Einzelpatch in main-Historie |

<a id="grenzbeobachter"></a>
### Grenzbeobachter und Übergangswerkstatt

Beobachtervergleich sowie lokale Übergänge mit Quellen und Replay.

| ID / Branch | Inhalt | Übernahmespur / Prüfstand |
| --- | --- | --- |
| B007 · [codex/grenzbeobachter-20261006](https://github.com/Juri-Halveth/halveth-scarlet/tree/a99e78c3b9565010a273f8f56f1aa8b96f8c8402)<br>`halveth-scarlet` · `a99e78c3b956` | Deterministische Grenzbeobachter mit UI und Tests | Einzelpatch in main-Historie |
| B051 · [codex/scarlet-transition-workshop](https://github.com/Juri-Halveth/halveth-scarlet/tree/273c50c6f3b756fe1ee4c9fe7b1ff14ad0de306a)<br>`halveth-scarlet` · `273c50c6f3b7` | Lokale Übergangswerkstatt mit Replay | Einzelpatch in main-Historie |

<a id="scarlet_platform"></a>
### SCARLET · Oberfläche und Betrieb

Spracheinstiege, Projekterklärung, Beobachterpanels und CI-Konfiguration.

| ID / Branch | Inhalt | Übernahmespur / Prüfstand |
| --- | --- | --- |
| B013 · [codex/hub-languages-cleanup](https://github.com/Juri-Halveth/halveth-scarlet/tree/a1ad8b1bf1d1af02ef74f58b6097a2fdc437f2c3)<br>`halveth-scarlet` · `a1ad8b1bf1d1` | Mehrsprachige Einstiege und Übersetzung | Einzelpatch in main-Historie |
| B047 · [codex/portfolio-clarity-20261020](https://github.com/Juri-Halveth/halveth-scarlet/tree/c632693a7d104cbaa741f9e99ff2e08a3ae0e2ef)<br>`halveth-scarlet` · `c632693a7d10` | Verständliche Projekt- und Arbeitsproben-Darstellung | Einzelpatch in main-Historie |
| B048 · [codex/scarlet-live-api-20261010](https://github.com/Juri-Halveth/halveth-scarlet/tree/0160accc1491361c6c9684fa09be8069cfb4c738)<br>`halveth-scarlet` · `0160accc1491` | Read-only-BTC-/GTC-Beobachter und zugehörige UI | Einzelpatch in main-Historie |
| B049 · [codex/scarlet-news-token-scope-20261010](https://github.com/Juri-Halveth/halveth-scarlet/tree/8f0f4ca417a4d91b7d25c052828eb829f708b525)<br>`halveth-scarlet` · `8f0f4ca417a4` | News-Workflow und Dependabot-Konfiguration | Abweichungen einzeln prüfen |
| B050 · [codex/scarlet-observer-panel-layout](https://github.com/Juri-Halveth/halveth-scarlet/tree/9ae09076bf9d2246664738ce96c44b55c32bc200)<br>`halveth-scarlet` · `9ae09076bf9d` | Layout der BTC-/GTC-Beobachterpanels | Einzelpatch in main-Historie |

<a id="portfolio"></a>
### Portfolio und Quellenhandbuch

Öffentlicher Einstieg, Übersetzungen, Arbeitsproben, Handbuch und Quellenuniversum.

| ID / Branch | Inhalt | Übernahmespur / Prüfstand |
| --- | --- | --- |
| B053 · [codex/adaptive-handbook](https://github.com/Juri-Halveth/Juri-Halveth.github.io/tree/5940fcec61112d5d5dda1eff0b2895c7f82d5f9a)<br>`Juri-Halveth.github.io` · `5940fcec6111` | Quellenhandbuch aktualisieren und russischen Lerneinstieg verbinden | Einzelpatch in main-Historie |
| B055 · [codex/github-constellation-ashbound](https://github.com/Juri-Halveth/Juri-Halveth.github.io/tree/171c2f7cf082cee21acd181ca929f8c687e7fe76)<br>`Juri-Halveth.github.io` · `171c2f7cf082` | Historische ASHBOUND-Präsentation im Portfolio | Abweichungen einzeln prüfen |
| B056 · [codex/halveth-black-hole-universe](https://github.com/Juri-Halveth/Juri-Halveth.github.io/tree/44f598d4c29244a1f2f617153fc6abfbad264365)<br>`Juri-Halveth.github.io` · `44f598d4c292` | Animiertes Quellenuniversum sowie gemischte CI-/Governance-Dateien | Abweichungen einzeln prüfen |
| B057 · [codex/hub-handbook](https://github.com/Juri-Halveth/Juri-Halveth.github.io/tree/8f20c3afaec226f9d7734f106692880c34884d09)<br>`Juri-Halveth.github.io` · `8f20c3afaec2` | Mehrsprachiges Quellenhandbuch und portabler Bash-Prüfweg | Einzelpatch in main-Historie |
| B058 · [codex/hub-languages-cleanup](https://github.com/Juri-Halveth/Juri-Halveth.github.io/tree/813f97c70e2d8a375f8cd11cc54dab99201f42fa)<br>`Juri-Halveth.github.io` · `813f97c70e2d` | Mehrsprachige Einstiege und Übersetzung inklusive Website-Generatoren | Gesamtpatch in main-Historie |
| B060 · [codex/portfolio-clarity-20261020](https://github.com/Juri-Halveth/Juri-Halveth.github.io/tree/0b7c21f18f3b94925e1e5ce11da8bcc0f3b5bae1)<br>`Juri-Halveth.github.io` · `0b7c21f18f3b` | Verständliche Projekt- und Arbeitsproben-Darstellung mit Portal-Generatoren | Gesamtpatch in main-Historie |
| B061 · [codex/visitor-learning-and-proof-20261007](https://github.com/Juri-Halveth/Juri-Halveth.github.io/tree/525c3f0d906922218a0e3170008b4327da85b85c)<br>`Juri-Halveth.github.io` · `525c3f0d9069` | Arbeitsproben, Erwachsenenlernen und Audit-Einstiege | Einzelpatch in main-Historie |

<a id="github_profile"></a>
### GitHub-Profil

Mehrsprachige Profiltexte, Arbeitsproben und historische Kompetenzdarstellung.

| ID / Branch | Inhalt | Übernahmespur / Prüfstand |
| --- | --- | --- |
| B063 · [codex/hub-languages-cleanup](https://github.com/Juri-Halveth/Juri-Halveth/tree/3bf3d7d2da059439aafbe07df22064b6fbbc4b84)<br>`Juri-Halveth` · `3bf3d7d2da05` | Mehrsprachige Einstiege und Übersetzung | Einzelpatch in main-Historie |
| B064 · [codex/portfolio-clarity-20261020](https://github.com/Juri-Halveth/Juri-Halveth/tree/d982162b72de09060b0f4dbda8c13f864c7184ba)<br>`Juri-Halveth` · `d982162b72de` | Verständliche Projekt- und Arbeitsproben-Darstellung | Einzelpatch in main-Historie |
| B065 · [codex/profile-certificates-visible-20261006](https://github.com/Juri-Halveth/Juri-Halveth/tree/7a1341172b468ab14a1c06d197a2697347e2f4e9)<br>`Juri-Halveth` · `7a1341172b46` | Historische Werkzertifikate und Portfolio-Dossiers | Einzelpatch in main-Historie |
| B066 · [codex/visitor-portfolio-20261007](https://github.com/Juri-Halveth/Juri-Halveth/tree/0acb9b14deaf3c13570687feeabab08e62966cb9)<br>`Juri-Halveth` · `0acb9b14deaf` | Kompakte Referenzen und direkte Arbeitsproben | Einzelpatch in main-Historie |
| B067 · [codex/visitor-table-labels-20261007](https://github.com/Juri-Halveth/Juri-Halveth/tree/f08a0e9a03d34960c6bfb192cd527751a110eb69)<br>`Juri-Halveth` · `f08a0e9a03d3` | Spaltenbezeichnungen der früheren Profilübersichten | Einzelpatch in main-Historie |

<a id="tresor"></a>
### Tresor · Projektanleitung

Spracheinstiege und verständliche Produktdarstellung; diese beiden Branches ändern Anleitungen.

| ID / Branch | Inhalt | Übernahmespur / Prüfstand |
| --- | --- | --- |
| B068 · [codex/hub-languages-cleanup](https://github.com/Juri-Halveth/halveth-tresor/tree/0ffcfe72651e0df3023334ad6a92529cdd34c193)<br>`halveth-tresor` · `0ffcfe72651e` | Mehrsprachige Einstiege und Übersetzung | Einzelpatch in main-Historie |
| B069 · [codex/portfolio-clarity-20261020](https://github.com/Juri-Halveth/halveth-tresor/tree/3fbf7945ba4e7caefe7f1d7c6374ddb8ad558ff6)<br>`halveth-tresor` · `3fbf7945ba4e` | Verständliche Projekt- und Arbeitsproben-Darstellung | Einzelpatch in main-Historie |

<a id="methods"></a>
### Eigenständige Methodenbeispiele

Zwei getrennte Beispiele: Hypothesen-Revision und Greif-/Weltkontext-Zustände.

| ID / Branch | Inhalt | Übernahmespur / Prüfstand |
| --- | --- | --- |
| B059 · [codex/ordinary-grip](https://github.com/Juri-Halveth/Juri-Halveth.github.io/tree/5012e52ad7be3c5f4a98412d00b84479c0931858)<br>`Juri-Halveth.github.io` · `5012e52ad7be` | Greifzustände mit erhaltener Objektidentität und Weltkontext | Einzelpatch in main-Historie |
| B062 · [codex/claimed-zda-correction](https://github.com/Juri-Halveth/Juri-Halveth/tree/86c0d4d6d0c1af2b8c20c464a22f1b3d2dad5a2e)<br>`Juri-Halveth` · `86c0d4d6d0c1` | Eigenständiger Hypothesen-Revision-Zyklus, CLI und HTTP-Adapter | Eigenständiger Quellstand |

<a id="schuelervz"></a>
### schülerVZ · Archivbetrieb

Wiederholbarer Push nach konkurrierenden Updates in den Archiv-Workflows.

| ID / Branch | Inhalt | Übernahmespur / Prüfstand |
| --- | --- | --- |
| B054 · [codex/archive-refresh-concurrent-push](https://github.com/Juri-Halveth/Juri-Halveth.github.io/tree/6fe9bce3a34c897f27a3a12e4b7c39d5b098484c)<br>`Juri-Halveth.github.io` · `6fe9bce3a34c` | Konkurrierende Aktualisierungen im schülerVZ-Archiv behandeln | Abweichungen einzeln prüfen |

<a id="handschrift"></a>
### Handschriftliche Konvergenzen

Historische Quellenstudie mit eigener Seite, Quellenregister und Testdatei.

| ID / Branch | Inhalt | Übernahmespur / Prüfstand |
| --- | --- | --- |
| B012 · [codex/hela-debbi-monolog-20260917](https://github.com/Juri-Halveth/halveth-scarlet/tree/ffb1b57dacfdba175f5cda81d7b43fa1ef450235)<br>`halveth-scarlet` · `ffb1b57dacfd` | Seite zur handschriftlichen Konvergenzstudie | Einzelpatch in main-Historie |

<a id="rights"></a>
### VOID25 · Rechte und Snapshot

Eigenes Metadatenpaket aus Rechteerklärung, Lizenzzuordnung und Snapshot-Anker.

| ID / Branch | Inhalt | Übernahmespur / Prüfstand |
| --- | --- | --- |
| B052 · [codex/void25-rights-20261006](https://github.com/Juri-Halveth/halveth-scarlet/tree/39031102e5329ca0e676c3359246ab3897aa6d1e)<br>`halveth-scarlet` · `39031102e532` | VOID25-Rechte- und Snapshot-Metadaten | Eigenständiger Quellstand |

## Sieben erhaltene Stände für gezielte Einzelprüfung

- **B006 · codex/ashbound-visual-balance** (halveth-scarlet): Als gemeinsame Vorgeschichte von vier offenen ASHBOUND-PRs erhalten; Änderungen mit deren Köpfen vergleichen.
- **B049 · codex/scarlet-news-token-scope-20261010** (halveth-scarlet): Abweichende Dateien und ihren heutigen Zweck einzeln prüfen; ein fehlender Patch-ID-Treffer allein beweist keinen fehlenden Nutzen.
- **B052 · codex/void25-rights-20261006** (halveth-scarlet): Eigenes Metadatenpaket erhalten; seine Bindung an den heutigen Lizenzbestand vor einer Veröffentlichung einzeln prüfen.
- **B054 · codex/archive-refresh-concurrent-push** (Juri-Halveth.github.io): Abweichende Dateien und ihren heutigen Zweck einzeln prüfen; ein fehlender Patch-ID-Treffer allein beweist keinen fehlenden Nutzen.
- **B055 · codex/github-constellation-ashbound** (Juri-Halveth.github.io): Als historischen Präsentationsentwurf erhalten. Die bereits entfernte Spielewerbung bleibt aus dem aktuellen Schaufenster.
- **B056 · codex/halveth-black-hole-universe** (Juri-Halveth.github.io): Abweichende Dateien und ihren heutigen Zweck einzeln prüfen; ein fehlender Patch-ID-Treffer allein beweist keinen fehlenden Nutzen.
- **B062 · codex/claimed-zda-correction** (Juri-Halveth): Als separates Methodenmodul auffindbar halten; CLI, Adapter-Grenze und eigene Lizenz vor möglicher Übernahme gezielt prüfen.


## Exportfassung

Diese abgeleitete Karte führt öffentliche Commit-, Pfad- und PR-Verweise. Lokale Backups und interne Originaljournale bleiben in der ursprünglichen Akte. Die Branch-Zuordnung behält ihren eigenen datierten Stand; die Websiteprüfung unten bindet eine spätere Revision.
