"use strict";
const search = document.querySelector("#search");
const project = document.querySelector("#project");
const state = document.querySelector("#state");
const rows = [...document.querySelectorAll(".branch")];
const normalize = text => text.normalize("NFKC").toLocaleLowerCase("de");
const text = new Map(rows.map(row => [row, normalize(row.textContent)]));
function update() {
  const query = normalize(search.value.trim());
  let count = 0;
  for (const row of rows) {
    row.hidden = Boolean((query && !text.get(row).includes(query)) || (project.value && row.dataset.project !== project.value) || (state.value && row.dataset.state !== state.value));
    if (!row.hidden) count++;
  }
  document.querySelector("#count").textContent = `${count} von ${rows.length} Branches`;
  document.querySelector("#empty").hidden = count !== 0;
}
search.addEventListener("input", update);
project.addEventListener("change", update);
state.addEventListener("change", update);
document.querySelector("#reset").addEventListener("click", () => { search.value = ""; project.value = ""; state.value = ""; update(); search.focus(); });
for (const link of document.querySelectorAll("[data-select-project]")) {
  link.addEventListener("click", () => { project.value = link.dataset.selectProject; state.value = ""; search.value = ""; update(); });
}
update();
